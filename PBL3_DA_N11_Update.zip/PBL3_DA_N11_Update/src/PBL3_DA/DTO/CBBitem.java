package PBL3_DA.DTO;

public class CBBitem {
	private int Value;
	private String Text;
	public int GetValue()
	{
		return Value;
	}
	public void SetValue(int value)
	{
		this.Value = value;
	}
	public String GetText()
	{
		return Text;
	}
	public void SetText(String text)
	{
		this.Text = text;
	}

}
