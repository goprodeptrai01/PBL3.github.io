package Main;

import PBL3_DA.GUI.OverviewFrame;

public class Main {

	public static void main(String[] args) {
		try {
			OverviewFrame OF = new OverviewFrame();
			OF.Open();
		} catch (Exception e) {
			// TODO: handle exception
		}

	}

}
